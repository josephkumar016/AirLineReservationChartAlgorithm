package com.joseph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 * AirLineReservationSystem Algorithm
 * 
 * @author TJOSEFKUMARA
 */
public class AirLineReservationSystem {

	static List<int[][]> rowList = new ArrayList<int[][]>();

	static List<Seat> seatingArragementList = new ArrayList<Seat>();

	static String inputData = "[[3,2],[4,3],[2,3],[3,4]]";

	/**
	 * Main Method to start the execution.
	 * 
	 * @param args is of type String Array
	 */
	public static void main(String[] args) {

//		Scanner in = new Scanner(System.in);
//		System.out.print("Enter the input data in the format of [[5,2],[4,3],[3,1],[2,4]]::::");
//		String inputData = in.nextLine();
//		System.out.print("Enter the number of Passengers:::");
//		int passengersCount = in.nextInt();

		int passengersCount = 30;

		int[][] result = formDataFromInputString(inputData);

		System.out.println("inputValue:::" + inputData);
		System.out.println("passengersCount to acccommodate:::" + passengersCount);


		List<Seat> seatingList = prepareSeating(result);
		
		Collections.sort(seatingList, new SortbyColumn());	

		Collections.sort(seatingList, new SortbySeatPosition());	

		preparePassengers(seatingList, passengersCount);		

		Comparator<Seat> compareByFields = Comparator.comparing(Seat::getRow).thenComparing(Seat::getColumn)
				.thenComparing(Seat::getBlock);

		seatingList = seatingList.stream().sorted(compareByFields).collect(Collectors.toList());

		printPassengerChart(result, seatingList);

	}

	/**
	 * Method to convert the Input Value to the Integer 2D Array
	 * 
	 * @param inputData is of type String
	 * @return value of type 2D Array
	 */
	public static int[][] formDataFromInputString(String inputData) {

		String inputValue = inputData.trim();
		inputValue = inputValue.substring(2, inputValue.length() - 2);


		String trimmedString = inputValue.replace("],[", "-");

		String lines[] = trimmedString.split("-");
		int width = lines.length;
		String cells[] = lines[0].split(",");
		int height = cells.length;
		int finalIntArray[][] = new int[width][height];

		for (int i = 0; i < width; i++) {
			String finalArray[] = lines[i].split(",");
			for (int j = 0; j < height; j++) {
				finalIntArray[i][j] = Integer.parseInt(finalArray[j]);
			}
		}
		return finalIntArray;
	}

	/**
	 * Method to prepare the Seating Objects List basing on the Input Data
	 * 
	 * @param inputArray is of type 2D integer Array
	 * @return value of type List of Seat objects
	 */
	public static List<Seat> prepareSeating(int[][] inputArray) {
		// Iterating the inputArray for preparing the Block Data
		// ([[5,2],[4,3],[3,1],[2,4]] -> 4 Blocks)
		for (int block = 1; block <= inputArray.length; block++) {
			// Iterating the InputArray for Preparing the Number Of Rows Data for each Block
			for (int row = 1; row <= inputArray[block - 1][0]; row++) {
				// Iterating the InputArray for Preparing the Number Of Column Data for each

				for (int column = 1; column <= inputArray[block - 1][1]; column++) {
					if (block == 1 && row == 1 && inputArray[block - 1][0] > 1) {
						Seat seat = new Seat(block, row, column, 2, 0);
						seatingArragementList.add(seat);
					} else if (block == inputArray.length && row == inputArray[block - 1][0]
							&& inputArray[block - 1][0] > 1) {
						Seat seat = new Seat(block, row, column, 2, 0);
						seatingArragementList.add(seat);
					} else if (row == 1 || row == (inputArray[block - 1][0])) {
						Seat seat = new Seat(block, row, column, 1, 0);
						seatingArragementList.add(seat);
					} else {
						Seat seat = new Seat(block, row, column, 3, 0);
						seatingArragementList.add(seat);
					}
				}
			}
		}
		return seatingArragementList;
	}

	/**
	 * Method to prepare the Passengers seating arrangement as per the Queue
	 * 
	 * @param seatingArragement is of type List
	 * @param queue             is of type integer
	 */
	public static void preparePassengers(List<Seat> seatingArragementList, int queue) {
		if (seatingArragementList.size() < queue) {
			for (int i = 0; i < seatingArragementList.size(); i++) {
				Seat seat = (Seat) seatingArragementList.get(i);
				seat.setPassenger(i + 1);
			}
		}else {
			for(int i=0;i<queue;i++) {
				Seat seat = (Seat) seatingArragementList.get(i);
				seat.setPassenger(i+1);
			}
		}
		
		
	}

	/**
	 * Method to print the final passenger chart to the Console
	 * 
	 * @param arrInput  is of type 2D array
	 * @param arrResult is of type List
	 */
	public static void printPassengerChart(int[][] arrInput, List<Seat> arrResult) {
		System.out.println("Final chart as per the Given Input Details:::");

		for (int i = 0; i < arrInput.length; i++) {
			for (int j = 0; j < arrInput[i][1]; j++) {
				for (int z = 0; z < arrResult.size(); z++) {
					if (arrResult.get(z).getBlock() == i + 1 && arrResult.get(z).getColumn() == j + 1) {
						System.out.print(arrResult.get(z).getPassenger());
						System.out.print(" ");
					}
				}
				System.out.println();
			}
			System.out.println();
		}
	}

}

/**
 * SortbyColumn class to Sort the Seat Object with the Column
 */
class SortbyColumn implements Comparator<Seat> {

	public int compare(Seat a, Seat b) {

		return a.getColumn() - b.getColumn();
	}
}

/**
 * SortbySeatPosition class to Sort the Seat Object with the SeatPostion
 */
class SortbySeatPosition implements Comparator<Seat> {

	public int compare(Seat a, Seat b) {

		return a.getSeatPosition() - b.getSeatPosition();
	}
}

/**
 * SortbyColumn class to Sort the Seat Object with the Column
 */
class SortbyRow implements Comparator<Seat> {

	public int compare(Seat a, Seat b) {

		return a.getRow() - b.getRow();
	}
}

/**
 * SortbyColumn class to Sort the Seat Object with the Column
 */
class SortbyBlock implements Comparator<Seat> {

	public int compare(Seat a, Seat b) {

		return a.getBlock() - b.getBlock();
	}
}
