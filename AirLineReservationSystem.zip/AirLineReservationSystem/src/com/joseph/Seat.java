package com.joseph;

/**
 *  Seat Class implements Comparator<Seat>
 * @author TJOSEFKUMARA
 *
 */
public class Seat {
	
	private int block;
	private int row;
	private int column;
	private int seatPosition;
	private int passenger;
	
	
	public Seat(int block, int row, int column, int seatPosition, int passenger) {
		super();
		this.block = block;
		this.row = row;
		this.column = column;
		this.seatPosition = seatPosition;
		this.passenger = passenger;
	}
	
	@Override
	public String toString() {
		return "Seat [block=" + block + ", row=" + row + ", column=" + column + ", seatPosition=" + seatPosition
				+ ", passenger=" + passenger + "]";
	}

	public int getBlock() {
		return block;
	}
	public void setBlock(int block) {
		this.block = block;
	}
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	public int getSeatPosition() {
		return seatPosition;
	}
	public void setSeatPosition(int seatPosition) {
		this.seatPosition = seatPosition;
	}
	public int getPassenger() {
		return passenger;
	}
	public void setPassenger(int passenger) {
		this.passenger = passenger;
	}

}
